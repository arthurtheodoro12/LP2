﻿namespace PTesteMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchTxtTexto = new System.Windows.Forms.RichTextBox();
            this.btnNum = new System.Windows.Forms.Button();
            this.btnSpace = new System.Windows.Forms.Button();
            this.btnLetra = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchTxtTexto
            // 
            this.rchTxtTexto.Location = new System.Drawing.Point(194, 70);
            this.rchTxtTexto.Name = "rchTxtTexto";
            this.rchTxtTexto.Size = new System.Drawing.Size(402, 195);
            this.rchTxtTexto.TabIndex = 0;
            this.rchTxtTexto.Text = "";
            // 
            // btnNum
            // 
            this.btnNum.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNum.Location = new System.Drawing.Point(194, 271);
            this.btnNum.Name = "btnNum";
            this.btnNum.Size = new System.Drawing.Size(121, 62);
            this.btnNum.TabIndex = 1;
            this.btnNum.Text = "Contar Números";
            this.btnNum.UseVisualStyleBackColor = true;
            this.btnNum.Click += new System.EventHandler(this.btnNum_Click);
            // 
            // btnSpace
            // 
            this.btnSpace.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSpace.Location = new System.Drawing.Point(330, 271);
            this.btnSpace.Name = "btnSpace";
            this.btnSpace.Size = new System.Drawing.Size(121, 62);
            this.btnSpace.TabIndex = 2;
            this.btnSpace.Text = "Mostrar Espaços";
            this.btnSpace.UseVisualStyleBackColor = true;
            this.btnSpace.Click += new System.EventHandler(this.btnSpace_Click);
            // 
            // btnLetra
            // 
            this.btnLetra.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetra.Location = new System.Drawing.Point(475, 271);
            this.btnLetra.Name = "btnLetra";
            this.btnLetra.Size = new System.Drawing.Size(121, 62);
            this.btnLetra.TabIndex = 3;
            this.btnLetra.Text = "Contar Letras";
            this.btnLetra.UseVisualStyleBackColor = true;
            this.btnLetra.Click += new System.EventHandler(this.btnLetra_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnLetra);
            this.Controls.Add(this.btnSpace);
            this.Controls.Add(this.btnNum);
            this.Controls.Add(this.rchTxtTexto);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchTxtTexto;
        private System.Windows.Forms.Button btnNum;
        private System.Windows.Forms.Button btnSpace;
        private System.Windows.Forms.Button btnLetra;
    }
}