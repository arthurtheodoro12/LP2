﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNum_Click(object sender, EventArgs e)
        {
            string texto = rchTxtTexto.Text;
            int cont = 0;
            int i = 0;

            while (i < texto.Length)
            {
                if (char.IsNumber(texto[i]))
                {
                    cont++;
                }
                i++;
            }
            MessageBox.Show($"Quantidade de números: {cont}");
        }

        private void btnSpace_Click(object sender, EventArgs e)
        {
            string texto = rchTxtTexto.Text;

            for (int i = 0; i < texto.Length; i++)
            {
                if (char.IsWhiteSpace(texto[i]))
                {
                    i++;
                    MessageBox.Show($"O primeiro espaço em branco está na posição: {i}");
                    return;
                }
            }

            MessageBox.Show("Nenhum espaço em branco foi encontrado.");
        }

        private void btnLetra_Click(object sender, EventArgs e)
        {
            string texto = rchTxtTexto.Text;
            int cont = 0;

            foreach (char caractere in texto)
            {
                if (char.IsLetter(caractere))
                {
                    cont++;
                }
            }

            MessageBox.Show($"Número de caracteres alfabéticos: {cont}");
        }
    }
}
