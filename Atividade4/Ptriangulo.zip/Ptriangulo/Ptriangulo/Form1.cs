﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double valorA, valorB, valorC;
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(txtValorA.Text, out valorA) || (valorA <= 0)) {
                MessageBox.Show("Valor de A inválido");
                txtValorA.Focus();
            }
        }
        private void txtValorB_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtValorB.Text, out valorB) || (valorB <= 0))
            {
                MessageBox.Show("Valor de B inválido");
                txtValorB.Focus();
            }
        }

        private void btnExec_Click(object sender, EventArgs e)
        {
            if ((valorA < (valorB + valorC)) && (valorA > Math.Abs(valorB - valorC)) && (valorB < (valorA + valorC)) && (valorB > Math.Abs(valorA - valorC)) && (valorC < (valorA + valorB)) && (valorC > Math.Abs(valorA - valorC))) {
                if((valorA == valorB) && (valorB == valorC))
                {
                    MessageBox.Show("Triângulo Equilátero");
                }
                else if((valorA == valorB) || (valorA == valorC) || (valorB == valorC))
                {
                    MessageBox.Show("Triângulo Isóceles");
                }
                else if((valorA != valorB) && (valorB  != valorC))
                {
                    MessageBox.Show("Triângulo Escaleno");
                }
            }
            else
            {
                MessageBox.Show("Os valores fornecidos não formam um triângulo");
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtValorC_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtValorC.Text, out valorC) || (valorC <= 0))
            {
                MessageBox.Show("Valor de C inválido");
                txtValorC.Focus();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

    }
}
