﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PEstudo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string num;

            for (int i = 0; i < vetor.Length; i++)
            {
                num = Interaction.InputBox($"Digite um número {i + 1}", "Entrada de Dados");
                if (!int.TryParse(num, out vetor[i]))
                {
                    MessageBox.Show("Número inválido");
                    i--;
                }
            }

            Array.Reverse(vetor);
            num = "";

            foreach (int i in vetor)
            {
                num += i + "\n";
            }

            MessageBox.Show(num);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList nomes = new ArrayList() { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" };
            string auxiliar = "";

            nomes.Remove("Otávio");

            foreach (string nome in nomes)
            {
                auxiliar += nome + "\n";
            }

            MessageBox.Show(auxiliar);

        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            double[,] alunosNotas = new double[20, 3];
            string auxiliar;
            double notas = 0, media = 0;
            string mostrar = "";

            for (int i = 0; i < alunosNotas.GetLength(0); i++)
            {
                for (int j = 0; j < alunosNotas.GetLength(1); j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a {j + 1}º nota do aluno {i + 1}", "Entrada de dados");

                    if (!double.TryParse(auxiliar, out alunosNotas[i, j]))
                    {
                        MessageBox.Show("Nota inválida");
                        j--;
                    }
                    else if (alunosNotas[i, j] < 0 || alunosNotas[i, j] > 10)
                    {
                        MessageBox.Show("Nota inválida");
                        j--;
                    }
                    else
                    {
                        notas += alunosNotas[i, j];
                        media = notas / 3;
                    }

                }

                mostrar += $"Aluno {i + 1}: média: {media.ToString("N2")}" + "\n";
                notas = 0;
            }

            MessageBox.Show(mostrar);
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio4>().Any())
            {
                Application.OpenForms.OfType<frmExercicio4>().First().BringToFront();
            }
            else
            {
                frmExercicio4 objFrm4 = new frmExercicio4();
                objFrm4.WindowState = FormWindowState.Maximized;
                objFrm4.Show();

            }
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio5>().Any())
            {
                Application.OpenForms.OfType<frmExercicio5>().First().BringToFront();
            }
            else
            {
                frmExercicio5 objFrm4 = new frmExercicio5();
                objFrm4.WindowState = FormWindowState.Maximized;
                objFrm4.Show();

            }
        }
    }
}
