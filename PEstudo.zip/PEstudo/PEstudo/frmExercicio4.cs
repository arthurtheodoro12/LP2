﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PEstudo
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[6];
            int comprimento;
            string auxiliar;
            string saida;

            for(int i = 0; i < nomes.Length; i++)
            {
                auxiliar = Interaction.InputBox("Digite um nome", "Entrada de Dados");
                comprimento = auxiliar.ToUpper().Replace(" ", "").Length;

                saida = $"O nome: {auxiliar} tem {comprimento} caracteres";

                lstbResultado.Items.Add(saida);
            }
        }
    }
}
