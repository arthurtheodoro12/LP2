﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PEstudo
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnComparar_Click(object sender, EventArgs e)
        {
            int[,] alunosQuestoes = new int[5, 10];
            char[] respostas = new char[10] {'A', 'A', 'B', 'C', 'A', 'D', 'D', 'E', 'A', 'E'};
            string auxiliar;

            for(int i = 0; i<alunosQuestoes.GetLength(0); i++)
            {
                for(int j = 0; j<alunosQuestoes.GetLength(1); j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a {j + 1}º resposta do aluno {i + 1}", "Entrada de dados");
                    
                    if ((auxiliar.Length == 1) && (auxiliar[0] >= 'A' && auxiliar[0] <= 'E'))
                    {
                        alunosQuestoes[i, j] = auxiliar[0];
                        if (alunosQuestoes[i, j] == respostas[j])
                        {
                            lstbResultado.Items.Add($"A {j + 1}º resposta do aluno {i + 1} foi:{auxiliar[0]} e está CORRETA!");
                        }
                        else
                        {
                            lstbResultado.Items.Add($"A {j + 1}º resposta do aluno {i + 1} foi:{auxiliar[0]} e está ERRADA!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Digite apenas letras MAIÚSCULAS de A a E");
                        j--;
                    }

                }
            }
        }
    }
}
