﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Configuration;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {
        double salBruto;
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void mskBoxNome_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }


        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void mskBoxNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((char.IsNumber(e.KeyChar)) || (char.IsPunctuation(e.KeyChar)))
            {
                MessageBox.Show("Caracter inválido!");
                SendKeys.Send("{BACKSPACE}");
            }
        }

        private void mskBoxSalario_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(mskBoxSalarioBruto.Text, out salBruto) || (salBruto <= 0)) {
                MessageBox.Show("Salário Inválido");
                mskBoxSalarioBruto.Focus();
            }
        }

        private void mskBoxSalarioBruto_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }
        private void btnVerificaDesconto_Click(object sender, EventArgs e)
        {
            double descontoINSS=0, descontoIRPF=0, salFamilia=0, salLiquido = 0;

            //Calcular INSS
            
            if (salBruto <= 800.47)
            {
                txtAliquotaINSS.Text = "7,65%";
                descontoINSS = ((7.65/100) * salBruto);
            }
            else if(salBruto <= 1050)
            {
                txtAliquotaINSS.Text = "8.65%";
                descontoINSS = ((8.65/100) * salBruto);
            }
            else if(salBruto <= 1400.77)
            {
                txtAliquotaINSS.Text = "9.00%";
                descontoINSS = ((9.0/100) * salBruto);
            }
            else if(salBruto <= 2801.56)
            {
                txtAliquotaINSS.Text = "11.00%";
                descontoINSS = ((11.0/100) * salBruto);
            }
            else if(salBruto > 2801.56)
            {
                txtAliquotaINSS.Text = "Teto";
                descontoINSS = 308.17;
            }
                txtDescontoINSS.Text = descontoINSS.ToString("F2");

            //Calcular IRPF
            
            if(salBruto <= 1257.12)
            {
                txtAliquotaIRPF.Text = "Isento";
                descontoIRPF = 0;
            }
            else if(salBruto <= 2512.08) 
            {
                txtAliquotaIRPF.Text = "15.00%";
                descontoIRPF = ((15.0/100) * salBruto);
            }
            else if(salBruto > 2512.08)
            {
                txtAliquotaIRPF.Text = "27.5%";
                descontoIRPF = ((27.5/100) * salBruto);
            }
                txtDescontoIRPF.Text= descontoIRPF.ToString("F2");

            //Calcular Salário Família

            if(salBruto <= 435.52)
            {
                salFamilia = (((double)numericUpDown1.Value) * 22.33);
            }
            else if(salBruto <= 654.61)
            {
                salFamilia = (((double)numericUpDown1.Value) * 15.74);
            }
            else if( salBruto > 654.61)
            {
                salFamilia = 0;
            }
            txtSalarioFamilia.Text = salFamilia.ToString("F2");

            //Calcular Salário Liquido 

            salLiquido = salBruto - descontoINSS - descontoIRPF + salFamilia;
            txtSalarioLiquido.Text = salLiquido.ToString("F2");
        }

        private void mskBoxNome_Validating(object sender, CancelEventArgs e)
        {
            if(mskBoxNome.Text == "")
            {
                MessageBox.Show("Nome inválido");
                mskBoxNome.Focus();
            }
        }
    }
}
