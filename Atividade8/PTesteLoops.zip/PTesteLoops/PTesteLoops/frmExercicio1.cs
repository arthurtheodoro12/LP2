﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteLoops
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }


        private void btnEspacosEmBranco_Click(object sender, EventArgs e)
        {
            int espacoBranco = 0;

            foreach (char caracter in rchtxtFrase.Text)
            {
                if (char.IsWhiteSpace(caracter))
                {
                    espacoBranco++;
                }
            }
            MessageBox.Show("O número de espaços em branco é: " + espacoBranco);
        }

        private void btnR_Click(object sender, EventArgs e)
        {
            string frase = rchtxtFrase.Text.ToUpper();
            int cont = 0;

            for (int i = 0; i < frase.Length; i++)
            {
                if (frase[i] == 'R')
                {
                    cont++;
                }
            }
            MessageBox.Show("O número de letras R é: " + cont);
        }

        private void btnPar_Click(object sender, EventArgs e)
        {
            string frase = rchtxtFrase.Text.ToUpper();
            int index = 0;
            int numVezes = 0;

            while (index < frase.Length - 1)
            {
                if (frase[index] == frase[index + 1])
                {
                    numVezes++;
                }
                index++;
            }
            MessageBox.Show("O número de vezes que ocorre um mesmo par de letras é: " + numVezes);
        }
    }
}
