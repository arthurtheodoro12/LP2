﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteLoops
{
    public partial class frmExercicio4 : Form
    {
        int prod;
        double B = 0, C = 0, D = 0, salBruto, sal, grat;
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
        private TextBox GetTxtSalBrut()
        {
            return txtSalBrut;
        }

        private void txtProd_TextChanged(object sender, EventArgs e)
        {
            if (!int.TryParse(txtProd.Text, out prod))
            {
                MessageBox.Show("Valor inválido");
                txtProd.Clear();
                txtProd.Focus();
            }
        }

        private void txtGrat_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(txtGrat.Text, out grat))
            {
                MessageBox.Show("Valor inválido");
                txtGrat.Clear();
                txtGrat.Focus();
            }
        }

        private void txtSal_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(txtSal.Text, out sal))
            {
                MessageBox.Show("Valor inválido");
                txtSal.Clear();
                txtSal.Focus();
            }
        }

        private void btnSalBrut_Click(object sender, EventArgs e)
        {
            if (prod >= 150)
                D = 1;
            if (prod >= 120)
                C = 1;
            if (prod >= 100)
                B = 1;

            salBruto = sal + (sal * (0.05 * B + 0.1 * C + 0.1 * D)) + grat;

            if (salBruto >= 7000)
                salBruto = 7000 + grat;

            txtSalBrut.Text = salBruto.ToString("N2");
        }

        private void txtNome_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNome_Validated(object sender, EventArgs e)
        {
            if (txtNome.Text == "")
            {
                MessageBox.Show("Nome inválido");
                txtNome.Focus();
            }
        }

        private void txtMat_Validated(object sender, EventArgs e)
        {
            if (txtMat.Text == "")
            {
                MessageBox.Show("Matrícula inválida");
                txtMat.Focus();
            }
        }
    }
}
