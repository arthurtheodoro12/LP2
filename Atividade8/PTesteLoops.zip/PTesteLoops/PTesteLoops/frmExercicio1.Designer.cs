﻿namespace PTesteLoops
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            rchtxtFrase = new RichTextBox();
            btnEspacosEmBranco = new Button();
            btnR = new Button();
            btnPar = new Button();
            SuspendLayout();
            // 
            // rchtxtFrase
            // 
            rchtxtFrase.Font = new Font("Segoe UI", 14.25F);
            rchtxtFrase.Location = new Point(344, 33);
            rchtxtFrase.Margin = new Padding(4, 3, 4, 3);
            rchtxtFrase.Name = "rchtxtFrase";
            rchtxtFrase.Size = new Size(370, 282);
            rchtxtFrase.TabIndex = 0;
            rchtxtFrase.Text = "";
            // 
            // btnEspacosEmBranco
            // 
            btnEspacosEmBranco.Font = new Font("Segoe UI", 14.25F);
            btnEspacosEmBranco.Location = new Point(111, 33);
            btnEspacosEmBranco.Margin = new Padding(4, 3, 4, 3);
            btnEspacosEmBranco.Name = "btnEspacosEmBranco";
            btnEspacosEmBranco.Size = new Size(225, 90);
            btnEspacosEmBranco.TabIndex = 1;
            btnEspacosEmBranco.Text = "Espaços em branco na frase";
            btnEspacosEmBranco.UseVisualStyleBackColor = true;
            btnEspacosEmBranco.Click += btnEspacosEmBranco_Click;
            // 
            // btnR
            // 
            btnR.Font = new Font("Segoe UI", 14.25F);
            btnR.Location = new Point(111, 129);
            btnR.Margin = new Padding(4, 3, 4, 3);
            btnR.Name = "btnR";
            btnR.Size = new Size(225, 90);
            btnR.TabIndex = 2;
            btnR.Text = "Letras R's na frase";
            btnR.UseVisualStyleBackColor = true;
            btnR.Click += btnR_Click;
            // 
            // btnPar
            // 
            btnPar.Font = new Font("Segoe UI", 14.25F);
            btnPar.Location = new Point(111, 225);
            btnPar.Margin = new Padding(4, 3, 4, 3);
            btnPar.Name = "btnPar";
            btnPar.Size = new Size(225, 90);
            btnPar.TabIndex = 3;
            btnPar.Text = "Mesmo par de letras na frase";
            btnPar.UseVisualStyleBackColor = true;
            btnPar.Click += btnPar_Click;
            // 
            // frmExercicio1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnPar);
            Controls.Add(btnR);
            Controls.Add(btnEspacosEmBranco);
            Controls.Add(rchtxtFrase);
            Margin = new Padding(4, 3, 4, 3);
            Name = "frmExercicio1";
            Text = "frmExercicio1";
            ResumeLayout(false);
        }

        #endregion

        private RichTextBox rchtxtFrase;
        private Button btnEspacosEmBranco;
        private Button btnR;
        private Button btnPar;
    }
}