﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMC
{
    public partial class Form1 : Form
    {
        double IMC, Peso, Altura;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtAltura.Text, out Altura) || (Altura <= 0))
            {
                MessageBox.Show("Altura inválida");
                txtAltura.Focus();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            IMC = (Peso / (Altura * Altura));
            IMC = Math.Round(IMC, 1);
            txtResultado.Text = IMC.ToString();

            if(IMC < 18.5) 
            {
                MessageBox.Show("Seu IMC é de: " + IMC + " ele é classificado como magreza.");
            }
            else if (IMC < 25)
            {
                MessageBox.Show("Seu IMC é de: " + IMC + " ele é classificado como normal.");
            }
            else if (IMC < 30)
            {
                MessageBox.Show("Seu IMC é de: " + IMC + " ele é classificado como sobrepeso I.");
            }
            else if (IMC <= 39.9)
            {
                MessageBox.Show("Seu IMC é de: " + IMC + " ele é classificado como obesidade II.");
            }
            else
            {
                MessageBox.Show("Seu IMC é de: " + IMC + " ele é classificado como obesidade grave III.");
            }

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPeso.Text = string.Empty;
            txtAltura.Text = string.Empty;
            txtResultado.Text = string.Empty;
        }

        private void txtResultado_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtPeso.Text, out Peso) || (Peso <= 0))
            {
                MessageBox.Show("Peso inválido");
                txtPeso.Focus();
            }
        }
    }
}
