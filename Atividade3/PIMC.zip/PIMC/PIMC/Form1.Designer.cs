﻿namespace PIMC
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.digiteSeuPeso = new System.Windows.Forms.Label();
            this.txtPeso = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.digiteSuaAltura = new System.Windows.Forms.Label();
            this.txtAltura = new System.Windows.Forms.TextBox();
            this.Resultado = new System.Windows.Forms.Label();
            this.txtResultado = new System.Windows.Forms.TextBox();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // digiteSeuPeso
            // 
            this.digiteSeuPeso.AutoSize = true;
            this.digiteSeuPeso.Location = new System.Drawing.Point(52, 64);
            this.digiteSeuPeso.Name = "digiteSeuPeso";
            this.digiteSeuPeso.Size = new System.Drawing.Size(119, 20);
            this.digiteSeuPeso.TabIndex = 0;
            this.digiteSeuPeso.Text = "Digite seu peso";
            // 
            // txtPeso
            // 
            this.txtPeso.Location = new System.Drawing.Point(189, 58);
            this.txtPeso.Name = "txtPeso";
            this.txtPeso.Size = new System.Drawing.Size(188, 26);
            this.txtPeso.TabIndex = 1;
            this.txtPeso.Validated += new System.EventHandler(this.txtPeso_Validated);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(56, 250);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(189, 52);
            this.button1.TabIndex = 2;
            this.button1.Text = "Calcular IMC";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // digiteSuaAltura
            // 
            this.digiteSuaAltura.AutoSize = true;
            this.digiteSuaAltura.Location = new System.Drawing.Point(52, 118);
            this.digiteSuaAltura.Name = "digiteSuaAltura";
            this.digiteSuaAltura.Size = new System.Drawing.Size(124, 20);
            this.digiteSuaAltura.TabIndex = 3;
            this.digiteSuaAltura.Text = "Digite sua altura";
            // 
            // txtAltura
            // 
            this.txtAltura.Location = new System.Drawing.Point(189, 118);
            this.txtAltura.Name = "txtAltura";
            this.txtAltura.Size = new System.Drawing.Size(188, 26);
            this.txtAltura.TabIndex = 4;
            this.txtAltura.Validated += new System.EventHandler(this.txtAltura_Validated);
            // 
            // Resultado
            // 
            this.Resultado.AutoSize = true;
            this.Resultado.Location = new System.Drawing.Point(133, 179);
            this.Resultado.Name = "Resultado";
            this.Resultado.Size = new System.Drawing.Size(38, 20);
            this.Resultado.TabIndex = 5;
            this.Resultado.Text = "IMC";
            // 
            // txtResultado
            // 
            this.txtResultado.Enabled = false;
            this.txtResultado.Location = new System.Drawing.Point(189, 179);
            this.txtResultado.Name = "txtResultado";
            this.txtResultado.Size = new System.Drawing.Size(188, 26);
            this.txtResultado.TabIndex = 6;
            this.txtResultado.TextChanged += new System.EventHandler(this.txtResultado_TextChanged);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(251, 250);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(126, 52);
            this.btnLimpar.TabIndex = 7;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.txtResultado);
            this.Controls.Add(this.Resultado);
            this.Controls.Add(this.txtAltura);
            this.Controls.Add(this.digiteSuaAltura);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtPeso);
            this.Controls.Add(this.digiteSeuPeso);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label digiteSeuPeso;
        private System.Windows.Forms.TextBox txtPeso;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label digiteSuaAltura;
        private System.Windows.Forms.TextBox txtAltura;
        private System.Windows.Forms.Label Resultado;
        private System.Windows.Forms.TextBox txtResultado;
        private System.Windows.Forms.Button btnLimpar;
    }
}

